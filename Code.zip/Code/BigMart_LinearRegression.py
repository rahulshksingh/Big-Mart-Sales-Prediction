import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error
from lightgbm import LGBMRegressor
import optuna

# Load data
train_df = pd.read_csv("train_v9rqX0R.csv")
test_df = pd.read_csv("test_AbJTz2l.csv")

# Combine for preprocessing
train_df["source"] = "train"
test_df["source"] = "test"
test_df["Item_Outlet_Sales"] = np.nan
data = pd.concat([train_df, test_df])

# Fill missing values
data["Item_Weight"].fillna(data["Item_Weight"].mean(), inplace=True)
data["Outlet_Size"].fillna("Medium", inplace=True)

# Clean categorical
data["Item_Fat_Content"] = data["Item_Fat_Content"].replace({"LF": "Low Fat", "low fat": "Low Fat", "reg": "Regular"})
data["Years_Operated"] = 2020 - data["Outlet_Establishment_Year"]

# Encode categorical variables
le = LabelEncoder()
for col in ["Item_Fat_Content", "Outlet_Size", "Outlet_Location_Type", "Outlet_Type"]:
    data[col] = le.fit_transform(data[col])
data = pd.get_dummies(data, columns=["Item_Type", "Outlet_Identifier"])

# Split back
train_data = data[data["source"] == "train"].drop("source", axis=1)
test_data = data[data["source"] == "test"].drop(["source", "Item_Outlet_Sales"], axis=1)

X = train_data.drop(["Item_Outlet_Sales", "Item_Identifier"], axis=1)
y = train_data["Item_Outlet_Sales"]
X_test = test_data.drop("Item_Identifier", axis=1)

# Train-validation split
X_train, X_valid, y_train, y_valid = train_test_split(X, y, test_size=0.2, random_state=42)

# LightGBM + Optuna Tuning
def objective_lgbm(trial):
    params = {
        'n_estimators': trial.suggest_int('n_estimators', 100, 500),
        'max_depth': trial.suggest_int('max_depth', 3, 12),
        'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3),
        'num_leaves': trial.suggest_int('num_leaves', 20, 150),
        'subsample': trial.suggest_float('subsample', 0.5, 1.0),
        'colsample_bytree': trial.suggest_float('colsample_bytree', 0.5, 1.0),
        'random_state': 42
    }
    model = LGBMRegressor(**params)
    model.fit(X_train, y_train)
    pred = model.predict(X_valid)
    pred = np.maximum(0, pred)  # Prevent negative predictions
    rmse = mean_squared_error(y_valid, pred, squared=False)
    return rmse

study = optuna.create_study(direction='minimize')
study.optimize(objective_lgbm, n_trials=30)

# Final model
# final_model = LGBMRegressor(**study.best_params)
# final_model.fit(X, y)

final_model = LGBMRegressor(**lgbm_study.best_params)
final_model.fit(X, y)

test_preds = np.maximum(0, final_model.predict(X_test))  # Clip negatives

# Save submission
submission = pd.read_csv("sample_submission_8RXa3c6.csv")
submission['Item_Outlet_Sales'] = test_preds
submission.to_csv("BigMart_LGBM_Only_Optuna.csv", index=False)
print("Submission saved to BigMart_LGBM_Only_Optuna.csv")
 