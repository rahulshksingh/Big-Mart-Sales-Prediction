import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, KFold
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import mean_squared_error
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from catboost import CatBoostRegressor
from lightgbm import LGBMRegressor
from sklearn.ensemble import StackingRegressor
import warnings
warnings.filterwarnings("ignore")

def run_bigmart_stacking_ensemble():
    def preprocess():
        train_df = pd.read_csv("train_v9rqX0R.csv")
        test_df = pd.read_csv("test_AbJTz2l.csv")

        train_df["source"] = "train"
        test_df["source"] = "test"
        test_df["Item_Outlet_Sales"] = np.nan
        data = pd.concat([train_df, test_df])

        data["Item_Weight"].fillna(data["Item_Weight"].mean(), inplace=True)
        data["Outlet_Size"].fillna("Medium", inplace=True)
        data["Item_Fat_Content"] = data["Item_Fat_Content"].replace({"LF": "Low Fat", "low fat": "Low Fat", "reg": "Regular"})
        data["Years_Operated"] = 2025 - data["Outlet_Establishment_Year"]

        cap_value = train_df["Item_Outlet_Sales"].quantile(0.99)
        data.loc[data["source"] == "train", "Item_Outlet_Sales"] = np.minimum(
            data.loc[data["source"] == "train", "Item_Outlet_Sales"], cap_value
        )

        le_temp = LabelEncoder()
        data["Item_Fat_Content"] = le_temp.fit_transform(data["Item_Fat_Content"])

        data["Item_Category"] = data["Item_Identifier"].str[:2]
        data["MRP_bins"] = pd.qcut(data["Item_MRP"], 4, labels=False)
        data["Visibility_MRP"] = data["Item_Visibility"] * data["Item_MRP"]
        data["MRP_per_Year"] = data["Item_MRP"] / (data["Years_Operated"] + 1)
        data["Visibility_Score"] = data["Item_Visibility"] / (data["Item_Weight"] + 1)
        data["MRP_Visibility_Ratio"] = data["Item_MRP"] / (data["Item_Visibility"] + 1e-5)
        data["Fat_MRP"] = data["Item_Fat_Content"] * data["Item_MRP"]

        le = LabelEncoder()
        for col in ["Outlet_Size", "Outlet_Location_Type", "Outlet_Type", "Item_Category"]:
            data[col] = le.fit_transform(data[col])

        data = pd.get_dummies(data, columns=["Item_Type", "Outlet_Identifier"])

        train_data = data[data["source"] == "train"].drop("source", axis=1)
        test_data = data[data["source"] == "test"].drop(["source", "Item_Outlet_Sales"], axis=1)

        X = train_data.drop(["Item_Outlet_Sales", "Item_Identifier"], axis=1)
        y = train_data["Item_Outlet_Sales"]
        X_test = test_data.drop("Item_Identifier", axis=1)

        # Feature scaling
        scaler = StandardScaler()
        X = pd.DataFrame(scaler.fit_transform(X), columns=X.columns)
        X_test = pd.DataFrame(scaler.transform(X_test), columns=X_test.columns)

        return X, y, X_test

    # Preprocessing
    X, y, X_test = preprocess()
    X_train, X_valid, y_train, y_valid = train_test_split(X, y, test_size=0.2, random_state=42)

    base_models = [
        ("lgbm", LGBMRegressor(random_state=42)),
        ("catboost", CatBoostRegressor(verbose=0, random_state=42)),
        ("ridge", Ridge(random_state=42))
    ]

    meta_model = LGBMRegressor(random_state=42)

    stacking_model = StackingRegressor(estimators=base_models, final_estimator=meta_model, passthrough=True)
    stacking_model.fit(X_train, y_train)
    preds = np.maximum(0, stacking_model.predict(X_valid))
    rmse = mean_squared_error(y_valid, preds, squared=False)
    print(f"\nStacking Ensemble Validation RMSE: {rmse:.4f}")

    # Final model and submission
    stacking_model.fit(X, y)
    test_preds = np.maximum(0, stacking_model.predict(X_test))
    submission = pd.read_csv("sample_submission_8RXa3c6.csv")
    submission['Item_Outlet_Sales'] = test_preds
    submission.to_csv("BigMart_Stacking_Ensemble.csv", index=False)
    print("Submission saved to BigMart_Stacking_Ensemble.csv")

# Run the stacking ensemble
run_bigmart_stacking_ensemble()
