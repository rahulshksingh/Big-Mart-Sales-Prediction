import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
sns.set(style="whitegrid")
import warnings
warnings.filterwarnings('ignore')

# ------------------- Load Data -------------------
df = pd.read_csv("train_v9rqX0R.csv")

# ------------------- Clean Item_Fat_Content -------------------
df['Item_Fat_Content'] = df['Item_Fat_Content'].replace({
    'LF': 'Low Fat',
    'low fat': 'Low Fat',
    'reg': 'Regular'
})

# ------------------- Add Derived Feature -------------------
df['Outlet_Age'] = 2025 - df['Outlet_Establishment_Year']

# ------------------- Summary Table + Plot -------------------
def summarize_column(df, col):
    summary = df[col].value_counts().to_frame(name='Count')
    summary['Percentage'] = 100 * summary['Count'] / summary['Count'].sum()
    summary = summary.reset_index().rename(columns={'index': col})
    return summary

def plot_distribution(df, col):
    pct = df[col].value_counts(normalize=True) * 100
    plt.figure(figsize=(7,4))
    sns.barplot(x=pct.index, y=pct.values)
    plt.title(f"{col} Distribution (%)")
    plt.ylabel("Percentage")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

# ------------------- Univariate Categorical -------------------
categorical_cols = ['Item_Fat_Content', 'Item_Type', 'Outlet_Type', 'Outlet_Location_Type']
for col in categorical_cols:
    print(f"\n Summary of {col}:")
    print(summarize_column(df, col))
    plot_distribution(df, col)

# ------------------- Univariate Numerical -------------------
numerical_cols = ['Item_Weight', 'Item_Visibility', 'Item_MRP', 'Item_Outlet_Sales']
for col in numerical_cols:
    plt.figure(figsize=(6, 4))
    sns.histplot(df[col], bins=30, kde=True)
    plt.title(f"Distribution of {col}")
    plt.show()

# ------------------- Bivariate Analysis -------------------

# Boxplots: Categorical vs Target
for col in categorical_cols:
    plt.figure(figsize=(8, 4))
    sns.boxplot(x=col, y='Item_Outlet_Sales', data=df)
    plt.title(f'{col} vs Item_Outlet_Sales')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

# Scatterplots: Numerical vs Target
for col in ['Item_Weight', 'Item_Visibility', 'Item_MRP']:
    plt.figure(figsize=(6, 4))
    sns.scatterplot(x=col, y='Item_Outlet_Sales', data=df, alpha=0.6)
    plt.title(f'{col} vs Item_Outlet_Sales')
    plt.tight_layout()
    plt.show()

# ------------------- Correlation Heatmap -------------------
plt.figure(figsize=(8,6))
corr = df[['Item_Weight', 'Item_Visibility', 'Item_MRP', 'Outlet_Age', 'Item_Outlet_Sales']].corr()
sns.heatmap(corr, annot=True, fmt=".2f", cmap='coolwarm')
plt.title("Correlation Matrix")
plt.show()

# ------------------- Pairwise Plot -------------------
pairplot_cols = ['Item_Weight', 'Item_Visibility', 'Item_MRP', 'Outlet_Age', 'Item_Outlet_Sales']
sns.pairplot(df[pairplot_cols], diag_kind='kde', corner=True)
plt.suptitle("Pairwise Plot of Numerical Features", y=1.02)
plt.show()

# ------------------- Interaction Bar Plots -------------------

# Fat Content × Outlet Type
plt.figure(figsize=(10, 5))
sns.barplot(x='Item_Fat_Content', y='Item_Outlet_Sales', hue='Outlet_Type', data=df, ci='sd')
plt.title("Interaction: Fat_Content × Outlet_Type")
plt.tight_layout()
plt.show()

# Fat Content × Location Type
plt.figure(figsize=(10, 5))
sns.barplot(x='Item_Fat_Content', y='Item_Outlet_Sales', hue='Outlet_Location_Type', data=df, ci='sd')
plt.title("Interaction: Fat_Content × Location_Type")
plt.tight_layout()
plt.show()

# Item Type × Outlet Type (Top 10 item types only)
top_items = df['Item_Type'].value_counts().nlargest(10).index.tolist()
plt.figure(figsize=(12, 6))
sns.barplot(data=df[df['Item_Type'].isin(top_items)],
            x='Item_Type', y='Item_Outlet_Sales', hue='Outlet_Type', ci='sd')
plt.title("Interaction: Item_Type × Outlet_Type")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# ------------------- Interaction Heatmaps (Pivot Tables) -------------------

# Heatmap: Fat Content × Outlet Type
pivot1 = df.pivot_table(index='Item_Fat_Content', columns='Outlet_Type',
                        values='Item_Outlet_Sales', aggfunc='mean')
plt.figure(figsize=(8, 5))
sns.heatmap(pivot1, annot=True, fmt=".0f", cmap='YlGnBu')
plt.title("Heatmap: Avg Sales (Fat_Content × Outlet_Type)")
plt.show()

# Heatmap: Outlet_Location_Type × Outlet_Type
pivot2 = df.pivot_table(index='Outlet_Location_Type', columns='Outlet_Type',
                        values='Item_Outlet_Sales', aggfunc='mean')
plt.figure(figsize=(8, 5))
sns.heatmap(pivot2, annot=True, fmt=".0f", cmap='PuBu')
plt.title("Heatmap: Avg Sales (Location_Type × Outlet_Type)")
plt.show()
