# Final Aligned Code with Auto-Tuned Hyperparameters for BigMart Sales Prediction (Fixed for BrokenProcessPool)

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, KFold, GridSearchCV
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import mean_squared_error, make_scorer
from catboost import CatBoostRegressor
from lightgbm import LGBMRegressor, early_stopping, log_evaluation
from sklearn.neural_network import MLPRegressor
from scipy.optimize import minimize
import warnings
warnings.filterwarnings("ignore")

# -------- Load Data --------
train = pd.read_csv("train_v9rqX0R.csv")
test = pd.read_csv("test_AbJTz2l.csv")
train["source"] = "train"
test["source"] = "test"
data = pd.concat([train, test], axis=0, ignore_index=True)

# -------- Preprocessing --------
data['Item_Fat_Content'] = data['Item_Fat_Content'].replace({
    'LF': 'Low Fat', 'low fat': 'Low Fat', 'reg': 'Regular'
}).str.title()

# Fill missing numerics
data['Item_Weight'] = data['Item_Weight'].replace(0, np.nan)
data['Item_Weight'] = data['Item_Weight'].interpolate(method='linear')
data['Item_Visibility'] = data['Item_Visibility'].replace(0, np.nan)
data['Item_Visibility'] = data['Item_Visibility'].interpolate(method='linear')

# Impute Outlet Size
data['Outlet_Size'] = data.groupby('Outlet_Type')['Outlet_Size'].transform(
    lambda x: x.fillna(x.mode()[0]) if not x.mode().empty else x)

# Feature Engineering
data['Outlet_Age'] = 2013 - data['Outlet_Establishment_Year']
data['MRP_bins'] = pd.qcut(data['Item_MRP'], 4, labels=False, duplicates='drop')
data['Visibility_MRP'] = data['Item_Visibility'] * data['Item_MRP']
data['MRP_per_Year'] = data['Item_MRP'] / (data['Outlet_Age'] + 1)
data['Visibility_Score'] = data['Item_Visibility'] / (data['Item_Weight'] + 1)
data['MRP_Visibility_Ratio'] = data['Item_MRP'] / (data['Item_Visibility'] + 1e-5)

# Split again since we changed the full data above
train_final = data[data['source'] == 'train'].copy()
test_final = data[data['source'] == 'test'].copy()

# Label Encoding for all object/categorical columns
object_cols = data.select_dtypes(include=['object']).columns
for col in object_cols:
    if col not in ['Item_Identifier', 'Outlet_Identifier', 'source']:
        encoder = LabelEncoder()
        full_col = pd.concat([train_final[col], test_final[col]], axis=0).astype(str)
        encoder.fit(full_col)
        train_final[col] = encoder.transform(train_final[col].astype(str))
        test_final[col] = encoder.transform(test_final[col].astype(str))

# Label Encoding for IDs (needed for model input)
for col in ['Item_Identifier', 'Outlet_Identifier']:
    encoder = LabelEncoder()
    full_col = pd.concat([train_final[col], test_final[col]], axis=0).astype(str)
    encoder.fit(full_col)
    train_final[col] = encoder.transform(train_final[col].astype(str))
    test_final[col] = encoder.transform(test_final[col].astype(str))

# Final train/test extraction
X = train_final.drop(columns=['source', 'Item_Outlet_Sales'])
y = train_final['Item_Outlet_Sales']
X_test = test_final.drop(columns=['source', 'Item_Outlet_Sales'])

print("Final training sample size:", X.shape[0])

# ---- Hyperparameter Tuning ----
rmse_scorer = make_scorer(mean_squared_error, greater_is_better=False)

# CatBoost Tuning (Manual Loop to Avoid Pickling Error)
best_cat = None
best_cat_rmse = float("inf")
for depth in [6, 8]:
    for lr in [0.03, 0.05]:
        model = CatBoostRegressor(depth=depth, learning_rate=lr, iterations=500, verbose=0, random_state=42)
        model.fit(X, y)
        preds = model.predict(X)
        score = mean_squared_error(y, preds, squared=False)
        if score < best_cat_rmse:
            best_cat_rmse = score
            best_cat = model

# LightGBM Tuning
lgb_params = {
    'learning_rate': [0.03, 0.05],
    'num_leaves': [31, 64],
    'n_estimators': [500],
    'min_child_samples': [20, 30],
    'lambda_l1': [0, 1],
    'lambda_l2': [0, 1]
}
lgb_grid = GridSearchCV(LGBMRegressor(random_state=42), lgb_params, scoring=rmse_scorer, cv=3, n_jobs=1)
lgb_grid.fit(X, y)
best_lgb = lgb_grid.best_estimator_

# MLP Tuning
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
X_test_scaled = scaler.transform(X_test)

mlp_params = {
    'hidden_layer_sizes': [(64, 32), (128, 64)],
    'alpha': [0.0001, 0.001],
    'max_iter': [500]
}
mlp_grid = GridSearchCV(MLPRegressor(random_state=42), mlp_params, scoring=rmse_scorer, cv=3, n_jobs=1)
mlp_grid.fit(X_scaled, y)
best_mlp = mlp_grid.best_estimator_

# ---- Prediction with Cross-Validation ----
kf = KFold(n_splits=5, shuffle=True, random_state=42)
cat_preds = np.zeros(X_test.shape[0])
lgb_preds = np.zeros(X_test.shape[0])
mlp_preds = np.zeros(X_test.shape[0])

for train_idx, val_idx in kf.split(X):
    X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
    y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]

    best_cat.fit(X_train, y_train, eval_set=(X_val, y_val), verbose=False)
    cat_preds += best_cat.predict(X_test) / kf.n_splits

    best_lgb.fit(X_train, y_train, eval_set=[(X_val, y_val)], callbacks=[early_stopping(50), log_evaluation(0)])
    lgb_preds += best_lgb.predict(X_test) / kf.n_splits

    best_mlp.fit(X_scaled[train_idx], y_train)
    mlp_preds += best_mlp.predict(X_test_scaled) / kf.n_splits

# ---- Optimized Ensemble Weights ----
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def blend(weights):
    return rmse(y, weights[0]*best_cat.predict(X) + weights[1]*best_lgb.predict(X) + weights[2]*best_mlp.predict(X_scaled))

opt_result = minimize(blend, [1/3, 1/3, 1/3], method='SLSQP', bounds=[(0,1)]*3, constraints={'type': 'eq', 'fun': lambda w: 1-sum(w)})
opt_weights = opt_result.x
print(f"Optimized Weights: {opt_weights}")

final_preds = opt_weights[0]*cat_preds + opt_weights[1]*lgb_preds + opt_weights[2]*mlp_preds

submission = pd.DataFrame({
    "Item_Identifier": test["Item_Identifier"],
    "Outlet_Identifier": test["Outlet_Identifier"],
    "Item_Outlet_Sales": final_preds
})

submission.to_csv("BigMart_Optimized_Ensemble2.csv", index=False)
print("Submission saved as BigMart_Optimized_Ensemble2.csv")
#this is best so far