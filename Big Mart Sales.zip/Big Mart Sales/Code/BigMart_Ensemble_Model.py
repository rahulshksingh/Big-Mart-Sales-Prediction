# Final Aligned Code: BigMart Sales Prediction (Fixed Categorical Conversion Bug)

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, KFold
from sklearn.preprocessing import LabelEncoder, KBinsDiscretizer
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
from lightgbm import LGBMRegressor, early_stopping, log_evaluation
from sklearn.neural_network import MLPRegressor
from scipy.optimize import minimize
import warnings
warnings.filterwarnings("ignore")

# -------- Load Data --------
train = pd.read_csv("train_v9rqX0R.csv")
test = pd.read_csv("test_AbJTz2l.csv")
train["source"] = "train"
test["source"] = "test"
data = pd.concat([train, test], axis=0, ignore_index=True)

# -------- Preprocessing --------
data['Item_Fat_Content'] = data['Item_Fat_Content'].replace({
    'LF': 'Low Fat', 'low fat': 'Low Fat', 'reg': 'Regular'
}).str.title()

# Fill missing numerics
data['Item_Weight'] = data['Item_Weight'].replace(0, np.nan)
data['Item_Weight'] = data['Item_Weight'].interpolate(method='linear')
data['Item_Visibility'] = data['Item_Visibility'].replace(0, np.nan)
data['Item_Visibility'] = data['Item_Visibility'].interpolate(method='linear')

# Impute Outlet Size
data['Outlet_Size'] = data.groupby('Outlet_Type')['Outlet_Size'].transform(
    lambda x: x.fillna(x.mode()[0]) if not x.mode().empty else x)

# Feature Engineering
data['Outlet_Age'] = 2013 - data['Outlet_Establishment_Year']
data['MRP_bins'] = pd.qcut(data['Item_MRP'], 4, labels=False, duplicates='drop')
data['Visibility_MRP'] = data['Item_Visibility'] * data['Item_MRP']
data['MRP_per_Year'] = data['Item_MRP'] / (data['Outlet_Age'] + 1)
data['Visibility_Score'] = data['Item_Visibility'] / (data['Item_Weight'] + 1)
data['MRP_Visibility_Ratio'] = data['Item_MRP'] / (data['Item_Visibility'] + 1e-5)

# Split again since we changed the full data above
train_final = data[data['source'] == 'train'].copy()
test_final = data[data['source'] == 'test'].copy()

# Label Encoding for all object/categorical columns
object_cols = data.select_dtypes(include=['object']).columns
for col in object_cols:
    if col not in ['Item_Identifier', 'Outlet_Identifier', 'source']:
        encoder = LabelEncoder()
        full_col = pd.concat([train_final[col], test_final[col]], axis=0).astype(str)
        encoder.fit(full_col)
        train_final[col] = encoder.transform(train_final[col].astype(str))
        test_final[col] = encoder.transform(test_final[col].astype(str))

# Label Encoding for IDs (needed for model input)
for col in ['Item_Identifier', 'Outlet_Identifier']:
    encoder = LabelEncoder()
    full_col = pd.concat([train_final[col], test_final[col]], axis=0).astype(str)
    encoder.fit(full_col)
    train_final[col] = encoder.transform(train_final[col].astype(str))
    test_final[col] = encoder.transform(test_final[col].astype(str))

# Final train/test extraction
X = train_final.drop(columns=['source', 'Item_Outlet_Sales'])
y = train_final['Item_Outlet_Sales']
X_test = test_final.drop(columns=['source', 'Item_Outlet_Sales'])

# ---- Sanity Check ----
print("Final training sample size:", X.shape[0])
if X.shape[0] < 5:
    raise ValueError(f"Not enough training samples after preprocessing: {X.shape[0]} rows. Check preprocessing filters.")

kf = KFold(n_splits=5, shuffle=True, random_state=42)
cat_preds = np.zeros(X_test.shape[0])
lgb_preds = np.zeros(X_test.shape[0])
mlp_preds = np.zeros(X_test.shape[0])

for train_idx, val_idx in kf.split(X):
    X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
    y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]

    # CatBoost
    cat = CatBoostRegressor(verbose=0, random_state=42)
    cat.fit(X_train, y_train, eval_set=(X_val, y_val))
    cat_preds += cat.predict(X_test) / kf.n_splits

    # LightGBM
    lgb = LGBMRegressor(n_estimators=1000, random_state=42)
    lgb.fit(X_train, y_train, eval_set=[(X_val, y_val)], callbacks=[early_stopping(50), log_evaluation(0)])
    lgb_preds += lgb.predict(X_test) / kf.n_splits

    # MLP
    mlp = MLPRegressor(hidden_layer_sizes=(64, 32), max_iter=500, random_state=42)
    mlp.fit(X_train, y_train)
    mlp_preds += mlp.predict(X_test) / kf.n_splits

# -------- Weight Optimization --------
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def blend(weights):
    final_preds = weights[0]*cat_preds + weights[1]*lgb_preds + weights[2]*mlp_preds
    cat_train = cat.predict(X)
    lgb_train = lgb.predict(X)
    mlp_train = mlp.predict(X)
    return rmse(y, weights[0]*cat_train + weights[1]*lgb_train + weights[2]*mlp_train)

opt_result = minimize(blend, [1/3, 1/3, 1/3], method='SLSQP', bounds=[(0,1)]*3, constraints={'type': 'eq', 'fun': lambda w: 1-sum(w)})
opt_weights = opt_result.x
print(f"Optimized Weights: {opt_weights}")

final_preds = opt_weights[0]*cat_preds + opt_weights[1]*lgb_preds + opt_weights[2]*mlp_preds

submission = pd.DataFrame({
    "Item_Identifier": test["Item_Identifier"],
    "Outlet_Identifier": test["Outlet_Identifier"],
    "Item_Outlet_Sales": final_preds
})

submission.to_csv("BigMart_Ensemble_Submission1.csv", index=False)
print("Submission saved as BigMart_Ensemble_Submission1.csv")
